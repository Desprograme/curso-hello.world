<h1> Código-fonte </h1>

<p>É assustador olhar um código-fonte quando estamos começando. Se você não sabe o que é, clique com o botão direito em cima desta página, ou de outra qualquer e vá em “exibir código fonte”(ou dependendo do navegador pode ser crtl+u).</p>

<p>Veja quanta coisa! Porém, você não deve temer tanta informação junta. Você, com empenho, será capaz de criar e interpretar grande parte dos códigos ali existentes. Para isso uma dica simples: Não enxergue ele como um todo e sim por partes. Um trecho de código de cada vez. Linha por linha. Ficará muito mais fácil e o monstro se dissipará.
</p>


